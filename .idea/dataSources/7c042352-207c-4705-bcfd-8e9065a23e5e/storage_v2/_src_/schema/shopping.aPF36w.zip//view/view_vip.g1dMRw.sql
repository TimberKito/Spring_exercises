create view view_vip as
select `uv`.`vip_name` AS `vip_name`, `u`.`user_name` AS `user_name`, count(`oi`.`user_id`) AS `purchase_times`
from ((`shopping`.`user_vip` `uv` left join `shopping`.`user` `u` on ((`u`.`id` = `uv`.`user_id`)))
         left join `shopping`.`order_info` `oi` on ((`uv`.`user_id` = `oi`.`user_id`)))
group by `oi`.`user_id`;

-- comment on column view_vip.vip_name not supported: VIP会员

