create
    definer = root@localhost procedure exaple_while()
BEGIN
-- 定义一个i变量  此变量默认初始值为1
DECLARE i INT DEFAULT 1;
-- 开始循环判断i是否大于100  如果是则执行添加语句
WHILE i<=100 DO
INSERT INTO footprint(user_id,product_id,date_time) VALUES (554,933,NOW());
-- 执行一次添加语句数值加一
SET i = i+1;
END WHILE;
END;

